(() => {
  "use strict";
  const c = document.getElementById("game"),
    ctx = c.getContext("2d");
  let W = innerWidth,
    H = innerHeight,
    dpr = Math.min(devicePixelRatio || 1, 2);
  function resize() {
    W = innerWidth;
    H = innerHeight;
    dpr = Math.min(devicePixelRatio || 1, 2);
    c.width = W * dpr;
    c.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  addEventListener("resize", resize);
  resize();

  const keys = {};
  addEventListener("keydown", (e) => {
    keys[e.key.toLowerCase()] = true;
    if (
      ["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(
        e.key.toLowerCase(),
      )
    )
      e.preventDefault();
  });
  addEventListener("keyup", (e) => (keys[e.key.toLowerCase()] = false));
  // Se a aba/janela perder o foco (minimizar, trocar de app, mudar de aba)
  // enquanto uma tecla está pressionada, o navegador não avisa quando ela é
  // solta. Sem isso, o personagem ficaria "andando sozinho" ou travado ao
  // voltar. Aqui zeramos tudo para o jogo voltar limpo.
  function soltarTodasAsTeclas() {
    for (const k in keys) keys[k] = false;
  }
  addEventListener("blur", soltarTodasAsTeclas);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) soltarTodasAsTeclas();
  });

  const ui = {
    start: document.getElementById("startScreen"),
    end: document.getElementById("endScreen"),
    hud: document.getElementById("hud"),
    math: document.getElementById("mathBox"),
    bottom: document.getElementById("bottom"),
    answer: document.getElementById("answer"),
    eq: document.getElementById("equation"),
    hint: document.getElementById("hint"),
    enemyHp: document.getElementById("enemyHp"),
    php: document.getElementById("playerHp"),
    hpText: document.getElementById("hpText"),
    lives: document.getElementById("lives"),
    score: document.getElementById("score"),
    kills: document.getElementById("kills"),
    mistakes: document.getElementById("mistakes"),
    combo: document.getElementById("combo"),
    message: document.getElementById("message"),
    flash: document.getElementById("flash"),
    stats: document.getElementById("stats"),
    grade: document.getElementById("grade"),
    endTitle: document.getElementById("endTitle"),
    endMessage: document.getElementById("endMessage"),
  };


  // Selo com o nome da fase (canto superior direito).
  const selo = document.createElement("div");
  selo.id = "f1Selo";
  selo.innerHTML =
    '<span class="f1-selo-num">Fase 1</span><span class="f1-selo-nome">A Torre de Heráclito</span>';
  document.getElementById("ui").appendChild(selo);

  function mostrarElementosDaFase1(mostrar) {
    selo.style.display = mostrar ? "block" : "none";
  }

  mostrarElementosDaFase1(false);



  const world = { w: 3600, h: 2200 };

  // Decoração do mapa: elementos visuais que deixam a torre mais viva sem exigir
  // imagens externas, arquivos adicionais ou internet. Eles são apenas cenários.
  const decor = [];
  function addDecor(type, x, y, scale = 1, rot = 0) {
    decor.push({ type, x, y, scale, rot });
  }
  (function buildDecor() {
    // Colunas e arcos
    [
      [360, 330],
      [900, 330],
      [1440, 330],
      [1980, 330],
      [2520, 330],
      [3060, 330],
      [620, 1870],
      [1160, 1870],
      [1700, 1870],
      [2240, 1870],
      [2780, 1870],
      [3320, 1870],
    ].forEach(([x, y]) => addDecor("pillar", x, y));
    // Estantes, baús e barris
    [
      [260, 560],
      [520, 520],
      [820, 610],
      [1280, 510],
      [1600, 610],
      [2050, 540],
      [2420, 610],
      [2860, 500],
      [3240, 620],
      [330, 1640],
      [760, 1710],
      [1120, 1600],
      [1500, 1720],
      [1880, 1600],
      [2320, 1710],
      [2700, 1600],
      [3100, 1700],
      [3400, 1580],
    ].forEach(([x, y], i) =>
      addDecor(
        i % 3 === 0 ? "shelf" : i % 3 === 1 ? "chest" : "barrel",
        x,
        y,
        1,
        (i % 2) * 0.08,
      ),
    );
    // Cristais mágicos
    [
      [700, 980],
      [1120, 1180],
      [1580, 860],
      [2050, 1040],
      [2500, 850],
      [3020, 1120],
      [900, 1450],
      [2220, 1460],
      [3200, 1380],
    ].forEach(([x, y], i) =>
      addDecor("crystal", x, y, 0.9 + (i % 3) * 0.15, (i % 4) * 0.2),
    );
    // Círculos mágicos
    [
      [560, 1120, 1.1],
      [1380, 1320, 0.85],
      [2180, 720, 1.05],
      [2940, 1440, 0.95],
      [3380, 900, 0.8],
    ].forEach(([x, y, sc]) => addDecor("circle", x, y, sc));
    // Tapetes e bandeiras
    [
      [1080, 980, 1.2],
      [1840, 1260, 1.0],
      [2760, 980, 1.15],
    ].forEach(([x, y, sc]) => addDecor("rug", x, y, sc));
    [
      [420, 760],
      [420, 1450],
      [1780, 210],
      [1780, 1990],
      [3140, 760],
      [3140, 1450],
    ].forEach(([x, y]) => addDecor("banner", x, y, 1));
    // Poças/rastros de magia e rachaduras
    [
      [980, 820],
      [2360, 1280],
      [3260, 460],
      [620, 1510],
      [1880, 520],
      [3000, 1760],
    ].forEach(([x, y], i) =>
      addDecor("rune", x, y, 1 + (i % 2) * 0.25, (i % 3) * 0.5),
    );
  })();

  let game = { running: false, paused: false },
    player = { x: 300, y: 1100, r: 24, dir: 0, speed: 210 },
    enemies = [],
    particles = [],
    keysDown = false,
    last = 0,
    elapsed = 0;
  const MAX_ENEMIES = 6;
  const SPAWN_INTERVAL = 1.6;
  const rand = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;
  function clamp(v, a, b) {
    return Math.max(a, Math.min(b, v));
  }
  function makeQuestion(level) {
    const types =
      level < 2
        ? ["add", "sub", "mul"]
        : level < 4
          ? ["add", "sub", "mul", "div", "pow"]
          : ["add", "sub", "mul", "div", "pow", "frac", "pct"];
    const t = types[rand(0, types.length - 1)];
    let a, b, ans, text;
    if (t === "add") {
      a = rand(4, 20 + level * 4);
      b = rand(2, 20 + level * 3);
      ans = a + b;
      text = `${a} + ${b} = ?`;
    } else if (t === "sub") {
      a = rand(10, 30 + level * 5);
      b = rand(2, a);
      ans = a - b;
      text = `${a} − ${b} = ?`;
    } else if (t === "mul") {
      a = rand(2, 7 + level);
      b = rand(2, 10);
      ans = a * b;
      text = `${a} × ${b} = ?`;
    } else if (t === "div") {
      b = rand(2, 9);
      ans = rand(2, 10 + level);
      a = b * ans;
      text = `${a} ÷ ${b} = ?`;
    } else if (t === "pow") {
      a = rand(2, 3 + (level > 4 ? 1 : 0));
      b = rand(2, 3);
      ans = Math.pow(a, b);
      text = `${a}${b === 3 ? "³" : "²"} = ?`;
    } else if (t === "frac") {
      const den = [2, 4, 5, 10][rand(0, 3)];
      const pct = den === 2 ? 50 : den === 4 ? 25 : den === 5 ? 20 : 10;
      const n = rand(2, 5) * den;
      ans = n / den;
      text = `${n} ÷ ${den} (ou ${pct}%) = ?`
    } else {
      const p = [10, 25, 50, 75][rand(0, 3)];
      a = rand(2, 8) * 4;
      ans = (a * p) / 100;
      text = `${p}% de ${a} = ?`;
    }
    return { text, ans: String(ans) };
  }
  function reset() {
    tocarMusicaFase(1);
    mostrarElementosDaFase1(true);
    game = {
      running: true,
      paused: false,
      terminal: false,
      terminalReason: "",
      lives: 3,
      hp: 7,
      maxHp: 7,
      score: 0,
      mistakes: 0,
      combo: 0,
      level: 1,
      kills: 0,
      start: performance.now(),
      time: 0,
      spawnTimer: 1.5,
      completed: false,
      bonus: false,
    };
    player = { x: 300, y: world.h / 2, r: 24, dir: 0, speed: 210 };
    enemies = [];
    particles = [];
    ui.start.style.display = "none";
    ui.end.style.display = "none";
    ui.hud.style.display = "block";
    ui.bottom.style.display = "block";
    ui.math.style.display = "none";
    ui.answer.value = "";
    updateHud();
    toast("Explore a Torre de Heráclito. Encontre os autômatos!");
  }
  function updateHud() {
    ui.php.style.width = (game.hp / game.maxHp) * 100 + "%";
    ui.hpText.textContent = game.hp + "/" + game.maxHp;
    ui.lives.textContent = game.lives;
    ui.score.textContent = game.score;
    ui.kills.textContent = game.kills + "/6";
    ui.mistakes.textContent = game.mistakes;
    ui.combo.textContent = "x" + game.combo;
  }
  function toast(t, ms = 1800) {
    ui.message.textContent = t;
    clearTimeout(toast.t);
    toast.t = setTimeout(() => (ui.message.textContent = ""), ms);
  }
  function spawnEnemy() {
    // Mantém os inimigos espalhados pelo mapa e longe do jogador.
    let x = 0,
      y = 0,
      valid = false;
    for (let i = 0; i < 80; i++) {
      x = rand(500, world.w - 350);
      y = rand(300, world.h - 300);
      const farPlayer = Math.hypot(x - player.x, y - player.y) > 650;
      const farEnemies = enemies.every(
        (other) => Math.hypot(x - other.x, y - other.y) > 260,
      );
      if (farPlayer && farEnemies) {
        valid = true;
        break;
      }
    }
    if (!valid) return;
    const q = makeQuestion(game.level);
    enemies.push({
      x,
      y,
      r: 34,
      hp: 3,
      maxHp: 3,
      q,
      active: false,
      phase: Math.random() * 7,
      id: Math.random(),
      wander: Math.random() * Math.PI * 2,
    });
  }

  function activate(e) {
    enemies.forEach((x) => (x.active = false));
    e.active = true;
    game.paused = true;
    ui.math.style.display = "block";
    ui.eq.textContent = e.q.text;
    ui.enemyHp.style.width = "100%";
    ui.answer.value = "";
    ui.hint.textContent = "Resolva e pressione Enter.";
    ui.hint.style.color = "#ffb2bd";
    setTimeout(() => ui.answer.focus(), 30);
  }
  ui.answer.addEventListener("input", () => {
    // As respostas são numéricas. Remove letras e símbolos que não fazem parte do resultado.
    const cleaned = ui.answer.value.replace(/[^0-9.,]/g, "");
    if (ui.answer.value !== cleaned) ui.answer.value = cleaned;
  });
  ui.answer.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && game.paused) {
      e.preventDefault();
      submitAnswer();
      return;
    }
    if (e.ctrlKey || e.metaKey || e.key.length !== 1) return;
    if (!/[0-9.,]/.test(e.key)) e.preventDefault();
  });
  ui.answer.addEventListener("paste", () =>
    setTimeout(() => {
      ui.answer.value = ui.answer.value.replace(/[^0-9.,]/g, "");
    }, 0),
  );
  function submitAnswer() {
    const e = enemies.find((x) => x.active);
    if (!e) return;
    const v = ui.answer.value.trim().replace(",", ".");
    if (v === "") return;
    if (v === e.q.ans) {
      e.hp--;
      game.combo++;
      game.score += 100 * game.combo;
      burst(e.x, e.y, 35, "spell");
      flash();
      ui.hint.textContent = "ACERTO! Feitiço lançado!";
      ui.hint.style.color = "#aaffcf";
      ui.answer.value = "";
      if (e.hp <= 0) {
        e.active = false;
        game.kills++;
        game.score += 250;
        game.level = Math.min(7, 1 + Math.floor(game.kills / 3));
        if (game.score >= 10000 && !game.bonus) {
          game.bonus = true;
          game.lives++;
          toast("10.000 PONTOS! +1 VIDA BÔNUS!", 2200);
        }
        if (Math.random() < 0.28) {
          game.hp = Math.min(game.maxHp, game.hp + 1);
          toast("Poção pequena! +1 HP", 1400);
        }
        burst(e.x, e.y, 60, "boom");
        enemies = enemies.filter((x) => x !== e);
        game.paused = false;
        ui.math.style.display = "none";
        if (game.lives > 0 && game.kills >= 6) {
          finish(true);
          return;
        }
        toast("Autômato destruído! Continue avançando.");
      } else {
        e.q = makeQuestion(game.level);
        ui.eq.textContent = e.q.text;
        ui.enemyHp.style.width = (e.hp / e.maxHp) * 100 + "%";
      }
    } else {
      game.combo = 0;
      game.mistakes++;
      game.hp--;
      burst(player.x, player.y, 18, "hit");
      ui.hint.textContent = "Resposta incorreta! O autômato atacou.";
      ui.hint.style.color = "#ff8fa0";
      ui.answer.value = "";
      let lostLife = false;
      if (game.mistakes % 5 === 0) {
        game.lives--;
        lostLife = true;
        toast("5 erros acumulados: -1 VIDA!", 1900);
      }
      if (game.hp <= 0) {
        if (!lostLife) {
          game.lives--;
          lostLife = true;
          toast("Seu HP acabou! Você perdeu uma vida.", 1800);
        }
        game.hp = game.maxHp;
      }
      // Um erro nunca pode tirar duas vidas de uma vez, mesmo quando o 5º erro também zera o HP.
      if (game.lives <= 0) {
        finish(false);
        return;
      }
      updateHud();
      setTimeout(() => ui.answer.focus(), 30);
    }
    updateHud();
  }
  function finish(win) {
    // Estado terminal: depois que uma partida termina, nenhuma outra condição
    // pode sobrescrever o resultado. GAME OVER tem prioridade absoluta.
    if (!game || !game.running || game.terminal) return;
    const won =
      Boolean(win) && Number(game.lives) > 0 && Number(game.kills) >= 6;

    mostrarElementosDaFase1(false);
    // Venceu a fase 1 e a fase 2 está disponível (index2.html carregou
    // fase2.js)? Então não é fim de jogo ainda: passamos o progresso
    // (HP, vidas, pontos, erros) para a fase 2 continuar de onde parou.
    if (won && window.FASE2 && typeof window.FASE2.iniciar === "function") {
      game.terminal = true;
      game.terminalReason = "fase2";
      game.running = false;
      game.paused = true;
      ui.math.style.display = "none";
      window.FASE2.iniciar({
        hp: game.hp,
        maxHp: game.maxHp,
        vidas: game.lives,
        pontos: game.score,
        erros: game.mistakes,
      });
      return;
    }

    game.terminal = true;
    game.terminalReason = won ? "win" : "gameover";
    game.running = false;
    game.paused = true;

    const secs = Math.max(0, (performance.now() - game.start) / 1000);
    const total = Number(game.kills || 0) + Number(game.mistakes || 0);
    const acc = total
      ? Math.max(0, Math.round((Number(game.kills || 0) / total) * 100))
      : 0;

    // Preenche TODOS os elementos antes de revelar a tela final.
    if (game.terminalReason === "gameover") {
      ui.endTitle.textContent = "GAME OVER";
      ui.grade.textContent = "Você perdeu!";
      ui.endMessage.textContent =
        "As 3 vidas de Pitágoras acabaram. Tente novamente!";
      ui.stats.innerHTML = `Pontuação: <b>${Number(game.score || 0).toLocaleString("pt-BR")}</b><br>Inimigos derrotados: <b>${Number(game.kills || 0)}</b>/6<br>Precisão: <b>${acc}%</b><br>Tempo: <b>${formatTime(secs)}</b>`;
    } else {
      ui.endTitle.textContent = "TORRE CONCLUÍDA!";
      ui.grade.textContent =
        acc >= 90
          ? "Mestre da Matemática!"
          : acc >= 70
            ? "Excelente!"
            : "Muito bom!";
      ui.endMessage.textContent = "Você restaurou o poder da matemática.";
      ui.stats.innerHTML = `Pontuação: <b>${Number(game.score || 0).toLocaleString("pt-BR")}</b><br>Inimigos derrotados: <b>${Number(game.kills || 0)}</b>/6<br>Precisão: <b>${acc}%</b><br>Tempo: <b>${formatTime(secs)}</b>`;
    }

    ui.end.classList.toggle("gameover", !won);
    ui.math.style.display = "none";
    ui.hud.style.display = "none";
    ui.bottom.style.display = "none";
    ui.end.style.display = "flex";
  }

  function formatTime(s) {
    return (
      Math.floor(s / 60) +
      ":" +
      String(Math.floor(s % 60)).padStart(2, "0")
    );
  }
  function flash(col = "#d9f8ff") {
    ui.flash.style.background = col;
    ui.flash.style.opacity = 0.45;
    setTimeout(() => (ui.flash.style.opacity = 0), 80);
  }
  function burst(x, y, n, type) {
    for (let i = 0; i < n; i++) {
      let a = Math.random() * Math.PI * 2,
        sp = rand(50, 260);
      particles.push({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rand(300, 800),
        max: 800,
        type,
      });
    }
  }
  function update(dt) {
    if (!game || !game.running) return;
    game.time = (performance.now() - game.start) / 1000;
    if (game.paused) return;
    let dx =
      (keys["d"] || keys["arrowright"] ? 1 : 0) -
      (keys["a"] || keys["arrowleft"] ? 1 : 0);
    let dy =
      (keys["s"] || keys["arrowdown"] ? 1 : 0) -
      (keys["w"] || keys["arrowup"] ? 1 : 0);
    if (dx || dy) {
      let l = Math.hypot(dx, dy);
      dx /= l;
      dy /= l;
      player.x += dx * player.speed * dt;
      player.y += dy * player.speed * dt;
      player.dir = Math.atan2(dy, dx);
    }
    player.x = clamp(player.x, 80, world.w - 80);
    player.y = clamp(player.y, 100, world.h - 100);

    // Mantém uma quantidade moderada de inimigos: há pressão, mas sem formar uma multidão.
    if (enemies.length < MAX_ENEMIES) {
      game.spawnTimer -= dt;
      if (game.spawnTimer <= 0) {
        spawnEnemy();
        game.spawnTimer = SPAWN_INTERVAL;
      }
    }

    // Apenas os dois autômatos não combatidos mais próximos podem perseguir.
    // Os demais vagam pelo mapa, evitando uma fila/aglomeração no jogador.
    const nearby = enemies
      .filter((e) => !e.active)
      .map((e) => ({ e, d: Math.hypot(player.x - e.x, player.y - e.y) }))
      .sort((a, b) => a.d - b.d);
    const chasers = new Set(
      nearby
        .slice(0, 4)
        .filter((item) => item.d < 800)
        .map((item) => item.e),
    );

    for (const e of enemies) {
      e.phase += dt * 2;
      e.wander += dt * (0.35 + game.level * 0.03);
      const ex = player.x - e.x,
        ey = player.y - e.y;
      const dist = Math.hypot(ex, ey) || 1;

      if (!e.active) {
        if (chasers.has(e)) {
          const chaseSpeed = 70 + game.level * 5;
          e.x += (ex / dist) * chaseSpeed * dt;
          e.y += (ey / dist) * chaseSpeed * dt;
        } else {
          e.x += Math.cos(e.wander) * 18 * dt;
          e.y += Math.sin(e.wander * 0.83) * 18 * dt;
        }
      }

      // Evita que os inimigos se empilhem/aglomerem.
      for (const other of enemies) {
        if (other === e || other.active) continue;
        const sx = e.x - other.x,
          sy = e.y - other.y,
          sd = Math.hypot(sx, sy);
        if (sd > 0 && sd < 115) {
          const push = ((115 - sd) / 115) * 55 * dt;
          e.x += (sx / sd) * push;
          e.y += (sy / sd) * push;
        }
      }
      e.x = clamp(e.x, 90, world.w - 90);
      e.y = clamp(e.y, 110, world.h - 110);
      if (dist < 85 && !e.active) activate(e);
    }
    particles.forEach((p) => {
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= 0.97;
      p.vy *= 0.97;
      p.life -= dt * 1000;
    });
    particles = particles.filter((p) => p.life > 0);
  }

  function draw() {
    ctx.clearRect(0, 0, W, H);
    const camX = clamp(player.x - W / 2, 0, world.w - W),
      camY = clamp(player.y - H / 2, 0, world.h - H);
    ctx.save();
    ctx.translate(-camX, -camY);
    // floor
    ctx.fillStyle = "#151323";
    ctx.fillRect(0, 0, world.w, world.h);
    // stone tiles
    for (let y = 0; y < world.h; y += 90)
      for (let x = 0; x < world.w; x += 120) {
        ctx.fillStyle =
          (x / 120 + y / 90) % 2 === 0 ? "#1b192a" : "#181625";
        ctx.fillRect(x + 2, y + 2, 116, 86);
        ctx.strokeStyle = "rgba(107,94,132,.18)";
        ctx.strokeRect(x + 2, y + 2, 116, 86);
      }
    drawDecorations();
    // magical paths
    ctx.strokeStyle = "rgba(52,213,255,.18)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(80, world.h / 2);
    ctx.lineTo(world.w - 80, world.h / 2);
    ctx.stroke();
    // outer walls
    ctx.strokeStyle = "#5d4c70";
    ctx.lineWidth = 28;
    ctx.strokeRect(20, 20, world.w - 40, world.h - 40);
    // runes
    ctx.font = "22px Georgia";
    ctx.fillStyle = "rgba(111,225,255,.35)";
    for (let i = 0; i < 45; i++) {
      let x = 100 + ((i * 173) % (world.w - 200)),
        y = 100 + ((i * 97) % (world.h - 200));
      ctx.fillText(["Δ", "π", "√", "x²", "%", "Σ"][i % 6], x, y);
    }
    // torches
    for (let x = 180; x < world.w; x += 480) drawTorch(x, 85);
    for (let x = 420; x < world.w; x += 480) drawTorch(x, world.h - 85);
    enemies.forEach(drawEnemy);
    drawPlayer();
    particles.forEach((p) => {
      ctx.globalAlpha = Math.max(0, p.life / p.max);
      ctx.fillStyle =
        p.type === "hit"
          ? "#ff5577"
          : p.type === "boom"
            ? "#ffd65e"
            : "#7eeaff";
      ctx.beginPath();
      ctx.arc(p.x, p.y, 3 + 8 * (p.life / p.max), 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    });
    ctx.restore();
  }
  function drawDecorations() {
    decor.forEach((d) => {
      ctx.save();
      ctx.translate(d.x, d.y);
      ctx.rotate(d.rot);
      ctx.scale(d.scale, d.scale);
      if (d.type === "pillar") {
        ctx.fillStyle = "#292638";
        ctx.fillRect(-20, -70, 40, 140);
        ctx.fillStyle = "#45405a";
        ctx.fillRect(-28, -78, 56, 14);
        ctx.fillRect(-28, 64, 56, 14);
        ctx.strokeStyle = "rgba(116,99,151,.45)";
        ctx.lineWidth = 3;
        ctx.strokeRect(-14, -55, 28, 110);
        ctx.fillStyle = "rgba(87,220,255,.18)";
        ctx.fillRect(-7, -55, 14, 110);
      } else if (d.type === "shelf") {
        ctx.fillStyle = "#3c2938";
        ctx.fillRect(-42, -45, 84, 90);
        ctx.fillStyle = "#7a5361";
        ctx.fillRect(-48, 40, 96, 8);
        ctx.fillRect(-48, -48, 96, 8);
        for (let i = -30; i <= 30; i += 15) {
          ctx.fillStyle = i % 30 === 0 ? "#7562a3" : "#a06c58";
          ctx.fillRect(i, -34, 9, 28);
          ctx.fillRect(i, 2, 9, 30);
        }
      } else if (d.type === "chest") {
        ctx.fillStyle = "#5a3a2d";
        ctx.fillRect(-35, -22, 70, 44);
        ctx.fillStyle = "#8a5a35";
        ctx.fillRect(-35, -22, 70, 9);
        ctx.strokeStyle = "#d0a45b";
        ctx.lineWidth = 4;
        ctx.strokeRect(-35, -22, 70, 44);
        ctx.fillStyle = "#d9c36a";
        ctx.fillRect(-5, -5, 10, 13);
      } else if (d.type === "barrel") {
        ctx.fillStyle = "#5b3d32";
        ctx.beginPath();
        ctx.ellipse(0, 0, 27, 35, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#b07a48";
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.ellipse(0, 0, 27, 35, 0, 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(-24, -12);
        ctx.lineTo(24, -12);
        ctx.moveTo(-24, 12);
        ctx.lineTo(24, 12);
        ctx.stroke();
      } else if (d.type === "crystal") {
        ctx.shadowBlur = 24;
        ctx.shadowColor = "#52e9ff";
        ctx.fillStyle = "#6ceaff";
        ctx.beginPath();
        ctx.moveTo(0, -34);
        ctx.lineTo(18, -8);
        ctx.lineTo(10, 30);
        ctx.lineTo(-13, 24);
        ctx.lineTo(-20, -8);
        ctx.closePath();
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.fillStyle = "rgba(255,255,255,.65)";
        ctx.beginPath();
        ctx.moveTo(-4, -25);
        ctx.lineTo(5, -12);
        ctx.lineTo(1, 8);
        ctx.lineTo(-8, -8);
        ctx.closePath();
        ctx.fill();
      } else if (d.type === "circle") {
        ctx.strokeStyle = "rgba(104,225,255,.48)";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(0, 0, 55, 0, Math.PI * 2);
        ctx.stroke();
        ctx.strokeStyle = "rgba(173,109,255,.42)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(0, 0, 38, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = "rgba(105,231,255,.15)";
        ctx.beginPath();
        ctx.arc(0, 0, 30, 0, Math.PI * 2);
        ctx.fill();
        ctx.font = "26px Georgia";
        ctx.fillStyle = "rgba(221,188,255,.7)";
        ctx.textAlign = "center";
        ctx.fillText("Σ", 0, 9);
      } else if (d.type === "rug") {
        ctx.fillStyle = "rgba(83,48,104,.85)";
        ctx.fillRect(-65, -32, 130, 64);
        ctx.strokeStyle = "#8e63ad";
        ctx.lineWidth = 4;
        ctx.strokeRect(-65, -32, 130, 64);
        ctx.strokeStyle = "rgba(99,219,255,.35)";
        ctx.lineWidth = 2;
        for (let i = -45; i <= 45; i += 15) {
          ctx.beginPath();
          ctx.moveTo(i, -27);
          ctx.lineTo(i, 27);
          ctx.stroke();
        }
      } else if (d.type === "banner") {
        ctx.fillStyle = "#8b6a3e";
        ctx.fillRect(-3, -55, 6, 110);
        ctx.fillStyle = "#6c3b9a";
        ctx.beginPath();
        ctx.moveTo(0, -45);
        ctx.lineTo(50, -30);
        ctx.lineTo(0, -12);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = "#65ddff";
        ctx.font = "20px Georgia";
        ctx.textAlign = "center";
        ctx.fillText("√", 18, -26);
      } else if (d.type === "rune") {
        ctx.strokeStyle = "rgba(112,220,255,.22)";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(-35, 10);
        ctx.lineTo(-5, -15);
        ctx.lineTo(20, 8);
        ctx.lineTo(38, -12);
        ctx.stroke();
        ctx.fillStyle = "rgba(184,122,255,.18)";
        ctx.beginPath();
        ctx.arc(0, 0, 18, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    });
  }
  function drawTorch(x, y) {
    ctx.fillStyle = "#3a3144";
    ctx.fillRect(x - 5, y, 10, 24);
    ctx.fillStyle = "#ff66ee";
    ctx.shadowBlur = 25;
    ctx.shadowColor = "#ff66ee";
    ctx.beginPath();
    ctx.arc(
      x,
      y - 5,
      12 + Math.sin(performance.now() / 120) * 2,
      0,
      Math.PI * 2,
    );
    ctx.fill();
    ctx.shadowBlur = 0;
  }
  function drawEnemy(e) {
    const bob = Math.sin(e.phase) * 3;
    ctx.save();
    ctx.translate(e.x, e.y + bob);
    ctx.shadowBlur = 18;
    ctx.shadowColor = e.active ? "#ff65e8" : "#48d9ff";
    ctx.fillStyle = "#34394b";
    ctx.beginPath();
    ctx.arc(0, 0, 30, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = "#1b1e2b";
    ctx.beginPath();
    ctx.arc(0, 2, 21, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = e.active ? "#ff6ee9" : "#6deaff";
    ctx.beginPath();
    ctx.arc(-9, -3, 5, 0, Math.PI * 2);
    ctx.arc(9, -3, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#75839c";
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(-25, 19);
    ctx.lineTo(-37, 34);
    ctx.moveTo(25, 19);
    ctx.lineTo(37, 34);
    ctx.stroke();
    ctx.fillStyle = "#10101a";
    ctx.fillRect(-34, -50, 68, 8);
    ctx.fillStyle = "#b4ffda";
    ctx.fillRect(-34, -50, 68 * (e.hp / e.maxHp), 8);
    ctx.restore();
  }
  function drawPlayer() {
    ctx.save();
    ctx.translate(player.x, player.y);
    ctx.shadowBlur = 18;
    ctx.shadowColor = "#67dcff";
    // cloak
    ctx.fillStyle = "#5b3bb1";
    ctx.beginPath();
    ctx.moveTo(-22, 25);
    ctx.quadraticCurveTo(0, 42, 22, 25);
    ctx.lineTo(17, -8);
    ctx.lineTo(-17, -8);
    ctx.closePath();
    ctx.fill();
    // head
    ctx.fillStyle = "#f0c6a7";
    ctx.beginPath();
    ctx.arc(0, -18, 14, 0, Math.PI * 2);
    ctx.fill();
    // hat
    ctx.fillStyle = "#24204c";
    ctx.beginPath();
    ctx.moveTo(-24, -21);
    ctx.lineTo(0, -58);
    ctx.lineTo(24, -21);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#a86cff";
    ctx.fillRect(-25, -22, 50, 7);
    // staff
    ctx.strokeStyle = "#d7b36c";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(25, 28);
    ctx.lineTo(35, -30);
    ctx.stroke();
    ctx.fillStyle = "#66efff";
    ctx.beginPath();
    ctx.arc(36, -34, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.restore();
  }
  let prev = performance.now();
  function loop(t) {
    const dt = Math.min(0.033, (t - prev) / 1000);
    prev = t;
    // Enquanto a fase 2 estiver ativa, ela é quem desenha no canvas.
    // Sem essa trava, as duas fases ficariam desenhando ao mesmo tempo.
    if (!(window.FASE2 && window.FASE2.ativa())) {
      update(dt);
      draw();
    }
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);

  document.getElementById("startBtn").onclick = reset;
  document.getElementById("restartBtn").onclick = reset;
})();