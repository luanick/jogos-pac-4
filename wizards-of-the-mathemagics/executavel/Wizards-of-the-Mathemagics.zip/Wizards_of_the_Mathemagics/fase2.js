/*
FASE2.iniciar(estado) -> script.js chama isso quando o jogador vence a fase 1. "estado" carrega HP, vidas, pontos 
erros para que o progresso continue.

FASE2.ativa() -> script.js consulta isso para saber se deve parar 
de desenhar (só um dos dois pode usar o canvas).

FASE2.encerrar() -> devolve o controle ao script.js (usado quando o jogador aperta "JOGAR NOVAMENTE").
 */

(() => {
  "use strict";
  const canvas = document.getElementById("game");
  const ctx = canvas.getContext("2d");
  let W = innerWidth;
  let H = innerHeight;

  function ajustarTela() {
    W = innerWidth;
    H = innerHeight;
    const dpr = Math.min(devicePixelRatio || 1, 2);
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  addEventListener("resize", () => {
    if (ativo) ajustarTela();
  });

  /* ---------------------------------------------------------------------
     2. ELEMENTOS DE INTERFACE a fase 2 só reutiliza o HUD.
     --------------------------------------------------------------------- */
  const ui = {
    hud: document.getElementById("hud"),
    math: document.getElementById("mathBox"),
    bottom: document.getElementById("bottom"),
    tutorial: document.getElementById("tutorial"),
    answer: document.getElementById("answer"),
    eq: document.getElementById("equation"),
    hint: document.getElementById("hint"),
    enemyName: document.getElementById("enemyName"),
    enemyHp: document.getElementById("enemyHp"),
    playerHp: document.getElementById("playerHp"),
    hpText: document.getElementById("hpText"),
    lives: document.getElementById("lives"),
    score: document.getElementById("score"),
    kills: document.getElementById("kills"),
    mistakes: document.getElementById("mistakes"),
    combo: document.getElementById("combo"),
    message: document.getElementById("message"),
    flash: document.getElementById("flash"),
    end: document.getElementById("endScreen"),
    endTitle: document.getElementById("endTitle"),
    endMessage: document.getElementById("endMessage"),
    grade: document.getElementById("grade"),
    stats: document.getElementById("stats"),
  };

  // Selo com o nome da fase (canto superior direito).
  const selo = document.createElement("div");
  selo.id = "f2Selo";
  selo.innerHTML =
    '<span class="f2-selo-num">Fase 2</span><span class="f2-selo-nome">As Criptas de Arquimedes</span>';
  document.getElementById("ui").appendChild(selo);

  // Barra de tempo da pergunta, colocada dentro da caixa de contas existente.
  const tempoWrap = document.createElement("div");
  tempoWrap.id = "f2Tempo";
  tempoWrap.innerHTML = '<div id="f2TempoFill"></div>';
  ui.math.appendChild(tempoWrap);


  function mostrarElementosDaFase(mostrar) {
    const seloFase1 = document.getElementById("f1Selo");

    if (seloFase1) {
      seloFase1.style.display = "none";
    }

    selo.style.display = mostrar ? "block" : "none";
    tempoWrap.style.display = mostrar ? "block" : "none";
  }

  mostrarElementosDaFase(false);


  /* ---------------------------------------------------------------------
     3. CONSTANTES DE BALANCEAMENTO
     Tudo que define a dificuldade da fase está aqui, em um lugar só.
     --------------------------------------------------------------------- */
  const MUNDO = { w: 4200, h: 2600 };
  const ALVO_SENTINELAS = 6; // quantas sentinelas para o Guardião aparecer
  const MAX_VIVAS = 6; // quantas podem existir ao mesmo tempo
  const INTERVALO_SPAWN = 2.2; // segundos entre nascimentos
  const VIDA_SENTINELA = 3; // acertos para destruir uma sentinela
  const VIDA_GUARDIAO = 7; // acertos para destruir o chefe
  const TEMPO_RESPOSTA = 15; // segundos por conta
  const TEMPO_RESPOSTA_CHEFE = 11; // o chefe aperta o relógio
  const VEL_JOGADOR = 225;

  /* ---------------------------------------------------------------------
     4. ESTADO
     --------------------------------------------------------------------- */
  let ativo = false; // a fase 2 está no comando do canvas?
  let terminada = false; // já mostrou a tela final?
  let loopLigado = false; // evita iniciar dois requestAnimationFrame
  let jogo = null;
  let jogador = null;
  let inimigos = [];
  let particulas = [];
  let alvo = null; // inimigo com a conta aberta
  let anterior = 0;

  const teclas = {};
  addEventListener("keydown", (e) => {
    if (!ativo) return;
    teclas[e.key.toLowerCase()] = true;
  });
  addEventListener("keyup", (e) => {
    teclas[e.key.toLowerCase()] = false;
  });
  // Mesma proteção contra tecla fantasma da fase 1: se a aba perder o foco
  // com uma tecla pressionada, o navegador não avisa quando ela é solta.
  function soltarTodasAsTeclas() {
    for (const k in teclas) teclas[k] = false;
  }
  addEventListener("blur", soltarTodasAsTeclas);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) soltarTodasAsTeclas();
  });

  const rand = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;
  const escolher = (lista) => lista[rand(0, lista.length - 1)];
  const limitar = (v, a, b) => Math.max(a, Math.min(b, v));

  /* ---------------------------------------------------------------------
     5. CENÁRIO
     Mesma técnica do script.js: uma lista de peças desenhadas com o próprio
     canvas, sem imagens externas. A paleta muda (gelo e âmbar no lugar do
     roxo) para o jogador perceber que trocou de lugar.
     --------------------------------------------------------------------- */
  const cenario = [];
  function peca(tipo, x, y, escala = 1, giro = 0) {
    cenario.push({ tipo, x, y, escala, giro });
  }
  (function montarCenario() {
    // Obeliscos formando corredores
    for (let x = 420; x < MUNDO.w - 300; x += 540) {
      peca("obelisco", x, 300);
      peca("obelisco", x + 270, MUNDO.h - 300);
    }
    // Estalactites de gelo nas bordas
    for (let x = 240; x < MUNDO.w - 200; x += 310) {
      peca("gelo", x, 150, 0.8 + ((x % 3) % 2) * 0.3);
      peca("gelo", x + 150, MUNDO.h - 150, 0.9);
    }
    // Engrenagens (a cripta é uma máquina de Arquimedes)
    [
      [760, 900, 1.2],
      [1500, 1500, 0.9],
      [2180, 820, 1.35],
      [2900, 1580, 1.05],
      [3560, 1000, 1.15],
      [1100, 1950, 0.95],
      [2600, 2050, 1.1],
    ].forEach(([x, y, s], i) => peca("engrenagem", x, y, s, i * 0.4));
    // Lagos congelados
    [
      [1180, 700, 1.3],
      [2450, 1820, 1.5],
      [3300, 600, 1.1],
      [640, 1700, 1.2],
    ].forEach(([x, y, s]) => peca("lago", x, y, s));
    // Braseiros
    [
      [500, 1300],
      [1400, 1150],
      [2300, 1320],
      [3200, 1250],
      [3900, 1600],
      [980, 2200],
      [2850, 480],
    ].forEach(([x, y]) => peca("braseiro", x, y));
    // Arcos quebrados
    [
      [1750, 420],
      [2050, 2180],
      [3450, 1900],
      [880, 520],
    ].forEach(([x, y], i) => peca("arco", x, y, 1, i * 0.05));
    // Glifos no chão
    for (let i = 0; i < 26; i++) {
      peca(
        "glifo",
        300 + ((i * 431) % (MUNDO.w - 600)),
        320 + ((i * 289) % (MUNDO.h - 640)),
        0.8 + (i % 3) * 0.2,
        (i % 5) * 0.6,
      );
    }
  })();

  /* ---------------------------------------------------------------------
     6. CONTAS
     A fase 2 usa outro gerador de perguntas, mais difícil que o da fase 1:
     ordem das operações, equações do 1º grau, raízes e potências.
     Todas as respostas são inteiras e positivas — o campo de resposta do
     jogo só aceita dígitos, então uma resposta negativa seria indigitável.
     --------------------------------------------------------------------- */
  /* ---------------------------------------------------------------------
     6. CONTAS (Fase 2 - Operações Simples: +, -, /, %)
     --------------------------------------------------------------------- */
  function novaConta(nivel) {
    const tipos = ["+", "-", "/", "%"];
    const t = escolher(tipos);
    let a, b, r, texto;

    if (t === "+") {
      a = rand(4, 25);
      b = rand(3, 25);
      r = a + b;
      texto = `${a} + ${b} = ?`;
    } else if (t === "-") {
      a = rand(10, 35);
      b = rand(2, a); // Garante resultado positivo
      r = a - b;
      texto = `${a} - ${b} = ?`;
    } else if (t === "/") {
      b = rand(2, 9); // divisor
      r = rand(2, 10); // quociente exato
      a = b * r; // dividendo exato
      texto = `${a} ÷ ${b} = ?`;
    } else {
      // Resto da divisão simples (%)
      b = rand(2, 6); // divisor
      a = rand(5, 25);
      r = a % b;
      texto = `${a} % ${b} = ?`;
    }

    return { texto, resposta: String(r) };
  }

  /* ---------------------------------------------------------------------
     7. HUD, AVISOS E EFEITOS
     --------------------------------------------------------------------- */
  function atualizarHud() {
    ui.playerHp.style.width = (jogo.hp / jogo.maxHp) * 100 + "%";
    ui.hpText.textContent = jogo.hp + "/" + jogo.maxHp;
    ui.lives.textContent = jogo.vidas;
    ui.score.textContent = jogo.pontos;
    ui.kills.textContent = jogo.chefeVivo
      ? "GUARDIÃO"
      : jogo.abates + "/" + ALVO_SENTINELAS;
    ui.mistakes.textContent = jogo.erros;
    ui.combo.textContent = "x" + jogo.combo;
  }

  let avisoTimer = null;
  function aviso(texto, ms = 1800) {
    ui.message.textContent = texto;
    clearTimeout(avisoTimer);
    avisoTimer = setTimeout(() => (ui.message.textContent = ""), ms);
  }

  function clarao(cor = "#b6fff0") {
    ui.flash.style.background = cor;
    ui.flash.style.opacity = 0.4;
    setTimeout(() => (ui.flash.style.opacity = 0), 80);
  }

  function explodir(x, y, n, tipo) {
    for (let i = 0; i < n; i++) {
      const ang = Math.random() * Math.PI * 2;
      const vel = rand(60, 300);
      particulas.push({
        x,
        y,
        vx: Math.cos(ang) * vel,
        vy: Math.sin(ang) * vel,
        vida: rand(300, 850),
        max: 850,
        tipo,
      });
    }
  }

  function formatarTempo(s) {
    return (
      Math.floor(s / 60) + ":" + String(Math.floor(s % 60)).padStart(2, "0")
    );
  }

  /* ---------------------------------------------------------------------
     8. INIMIGOS
     --------------------------------------------------------------------- */
  function nascerSentinela() {
    let x = 0;
    let y = 0;
    let ok = false;
    // Nascem em um anel ao redor do jogador: longe o bastante para não ser
    // injusto, perto o bastante para ele encontrar alguém sem varrer o mapa
    // inteiro. Se o anel estiver lotado, aceita qualquer ponto válido.
    for (let i = 0; i < 120; i++) {
      const solto = i > 80;
      if (solto) {
        x = rand(420, MUNDO.w - 420);
        y = rand(320, MUNDO.h - 320);
      } else {
        const ang = Math.random() * Math.PI * 2;
        const raio = rand(620, 1150);
        x = jogador.x + Math.cos(ang) * raio;
        y = jogador.y + Math.sin(ang) * raio;
      }
      const dentroDoMapa =
        x > 420 && x < MUNDO.w - 420 && y > 320 && y < MUNDO.h - 320;
      const longeDoJogador = Math.hypot(x - jogador.x, y - jogador.y) > 600;
      const longeDosOutros = inimigos.every(
        (o) => Math.hypot(x - o.x, y - o.y) > 230,
      );
      if (dentroDoMapa && longeDoJogador && longeDosOutros) {
        ok = true;
        break;
      }
    }
    if (!ok) return;
    inimigos.push({
      chefe: false,
      x,
      y,
      r: 34,
      hp: VIDA_SENTINELA,
      maxHp: VIDA_SENTINELA,
      conta: novaConta(jogo.nivel),
      ativo: false,
      fase: Math.random() * 7,
      vagar: Math.random() * Math.PI * 2,
    });
  }

  function nascerGuardiao() {
    jogo.chefeVivo = true;
    inimigos = [];
    inimigos.push({
      chefe: true,
      x: MUNDO.w / 2,
      y: MUNDO.h / 2,
      r: 62,
      hp: VIDA_GUARDIAO,
      maxHp: VIDA_GUARDIAO,
      conta: novaConta(6),
      ativo: false,
      fase: 0,
      vagar: 0,
    });
    aviso("O GUARDIÃO DE ARQUIMEDES DESPERTOU!", 2600);
    clarao("#ffd98a");
    atualizarHud();
  }

  /* ---------------------------------------------------------------------
     9. A CAIXA DE CONTAS
     --------------------------------------------------------------------- */
  function abrirConta(e) {
    inimigos.forEach((i) => (i.ativo = false));
    e.ativo = true;
    alvo = e;
    jogo.emConta = true;
    jogo.tempo = e.chefe ? TEMPO_RESPOSTA_CHEFE : TEMPO_RESPOSTA;
    jogo.tempoMax = jogo.tempo;
    ui.enemyName.textContent = e.chefe
      ? "GUARDIÃO DE ARQUIMEDES"
      : "SENTINELA DE GELO";
    ui.eq.textContent = e.conta.texto;
    ui.enemyHp.style.width = (e.hp / e.maxHp) * 100 + "%";
    ui.hint.textContent = "Resolva antes do tempo acabar.";
    ui.hint.style.color = "#ffd7a1";
    ui.answer.value = "";
    ui.math.style.display = "block";
    mostrarElementosDaFase(true);
    atualizarBarraTempo();
    setTimeout(() => ui.answer.focus(), 30);
  }

  function fecharConta() {
    jogo.emConta = false;
    alvo = null;
    ui.math.style.display = "none";
  }

  function atualizarBarraTempo() {
    const pct = limitar((jogo.tempo / jogo.tempoMax) * 100, 0, 100);
    const barra = document.getElementById("f2TempoFill");
    barra.style.width = pct + "%";
    barra.classList.toggle("f2-urgente", pct < 35);
  }

  // Um erro (ou o tempo esgotado) desconta HP. Ao zerar o HP, perde-se uma
  // vida e o HP é restaurado. Cinco erros acumulados também custam uma vida,
  // mas um mesmo erro nunca tira duas vidas de uma vez.
  function sofrerDano(motivo) {
    jogo.combo = 0;
    jogo.erros++;
    jogo.hp--;
    explodir(jogador.x, jogador.y, 20, "dano");
    ui.hint.textContent = motivo;
    ui.hint.style.color = "#ff96a8";

    let perdeuVida = false;
    if (jogo.erros % 5 === 0) {
      jogo.vidas--;
      perdeuVida = true;
      aviso("5 erros acumulados: -1 VIDA!", 1900);
    }
    if (jogo.hp <= 0) {
      if (!perdeuVida) {
        jogo.vidas--;
        perdeuVida = true;
        aviso("Seu HP acabou! Você perdeu uma vida.", 1800);
      }
      jogo.hp = jogo.maxHp;
    }

    if (jogo.vidas <= 0) {
      atualizarHud();
      encerrarFase(false);
      return true;
    }
    atualizarHud();
    return false;
  }

  function responder() {
    if (!ativo || terminada || !alvo) return;
    const valor = ui.answer.value.trim().replace(",", ".");
    if (valor === "") return;
    const e = alvo;

    if (valor === e.conta.resposta) {
      e.hp--;
      jogo.acertos++;
      jogo.combo++;
      jogo.pontos += (e.chefe ? 250 : 150) * jogo.combo;
      explodir(e.x, e.y, 40, "magia");
      clarao();
      ui.answer.value = "";
      ui.hint.textContent = "ACERTO! O feitiço atravessou o gelo.";
      ui.hint.style.color = "#9dffd8";

      if (e.hp <= 0) {
        explodir(e.x, e.y, 70, "estouro");
        inimigos = inimigos.filter((i) => i !== e);
        fecharConta();

        if (e.chefe) {
          jogo.pontos += 3000;
          atualizarHud();
          encerrarFase(true);
          return;
        }

        jogo.abates++;
        jogo.pontos += 400;
        jogo.nivel = Math.min(7, 2 + Math.floor(jogo.abates / 2));
        if (Math.random() < 0.3) {
          jogo.hp = Math.min(jogo.maxHp, jogo.hp + 1);
          aviso("Cristal de cura! +1 HP", 1400);
        } else {
          aviso("Sentinela despedaçada!");
        }
        if (jogo.abates >= ALVO_SENTINELAS) nascerGuardiao();
      } else {
        e.conta = novaConta(jogo.nivel);
        jogo.tempo = e.chefe ? TEMPO_RESPOSTA_CHEFE : TEMPO_RESPOSTA;
        jogo.tempoMax = jogo.tempo;
        ui.eq.textContent = e.conta.texto;
        ui.enemyHp.style.width = (e.hp / e.maxHp) * 100 + "%";
        atualizarBarraTempo();
      }
      atualizarHud();
      setTimeout(() => ui.answer.focus(), 20);
    } else {
      ui.answer.value = "";
      if (sofrerDano("Resposta incorreta! A sentinela revidou.")) return;
      setTimeout(() => ui.answer.focus(), 20);
    }
  }

  // O script.js também escuta o Enter neste campo, mas o handler dele sai
  // imediatamente quando não há inimigo ativo na fase 1 — então os dois
  // convivem sem conflito.
  ui.answer.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && ativo && !terminada) {
      e.preventDefault();
      responder();
    }
  });

  /* ---------------------------------------------------------------------
     10. ATUALIZAÇÃO POR QUADRO
     --------------------------------------------------------------------- */
  function atualizar(dt) {
    if (!jogo || terminada) return;

    // Com a conta aberta o mundo congela, mas o relógio continua correndo.
    if (jogo.emConta) {
      jogo.tempo -= dt;
      atualizarBarraTempo();
      if (jogo.tempo <= 0) {
        const alvoAtual = alvo;
        if (sofrerDano("O tempo acabou! A sentinela revidou.")) return;
        if (alvoAtual) {
          alvoAtual.conta = novaConta(jogo.nivel);
          jogo.tempo = alvoAtual.chefe
            ? TEMPO_RESPOSTA_CHEFE
            : TEMPO_RESPOSTA;
          jogo.tempoMax = jogo.tempo;
          ui.eq.textContent = alvoAtual.conta.texto;
          atualizarBarraTempo();
        }
      }
      return;
    }

    // Movimento do jogador
    let dx =
      (teclas["d"] || teclas["arrowright"] ? 1 : 0) -
      (teclas["a"] || teclas["arrowleft"] ? 1 : 0);
    let dy =
      (teclas["s"] || teclas["arrowdown"] ? 1 : 0) -
      (teclas["w"] || teclas["arrowup"] ? 1 : 0);
    if (dx || dy) {
      const l = Math.hypot(dx, dy);
      jogador.x += (dx / l) * VEL_JOGADOR * dt;
      jogador.y += (dy / l) * VEL_JOGADOR * dt;
    }
    jogador.x = limitar(jogador.x, 90, MUNDO.w - 90);
    jogador.y = limitar(jogador.y, 110, MUNDO.h - 110);

    // Nascimento de sentinelas (o chefe sozinho toma conta do mapa)
    if (!jogo.chefeVivo && inimigos.length < MAX_VIVAS) {
      jogo.spawn -= dt;
      if (jogo.spawn <= 0) {
        nascerSentinela();
        jogo.spawn = INTERVALO_SPAWN;
      }
    }

    // Só as três sentinelas mais próximas perseguem; o resto vagueia.
    const perseguidoras = new Set(
      inimigos
        .map((e) => ({ e, d: Math.hypot(jogador.x - e.x, jogador.y - e.y) }))
        .sort((a, b) => a.d - b.d)
        .slice(0, 3)
        .filter((i) => i.d < 820)
        .map((i) => i.e),
    );

    for (const e of inimigos) {
      e.fase += dt * 2;
      e.vagar += dt * (0.4 + jogo.nivel * 0.03);
      const ex = jogador.x - e.x;
      const ey = jogador.y - e.y;
      const dist = Math.hypot(ex, ey) || 1;

      if (e.chefe) {
        const vel = 78;
        e.x += (ex / dist) * vel * dt;
        e.y += (ey / dist) * vel * dt;
      } else if (perseguidoras.has(e)) {
        const vel = 62 + jogo.nivel * 6;
        e.x += (ex / dist) * vel * dt;
        e.y += (ey / dist) * vel * dt;
      } else {
        e.x += Math.cos(e.vagar) * 26 * dt;
        e.y += Math.sin(e.vagar * 0.8) * 26 * dt;
      }

      // Evita que se empilhem
      for (const outro of inimigos) {
        if (outro === e) continue;
        const sx = e.x - outro.x;
        const sy = e.y - outro.y;
        const sd = Math.hypot(sx, sy);
        if (sd > 0 && sd < 120) {
          const empurrao = ((120 - sd) / 120) * 60 * dt;
          e.x += (sx / sd) * empurrao;
          e.y += (sy / sd) * empurrao;
        }
      }

      e.x = limitar(e.x, 90, MUNDO.w - 90);
      e.y = limitar(e.y, 110, MUNDO.h - 110);
      if (dist < e.r + 55) {
        abrirConta(e);
        break;
      }
    }

    particulas.forEach((p) => {
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vx *= 0.97;
      p.vy *= 0.97;
      p.vida -= dt * 1000;
    });
    particulas = particulas.filter((p) => p.vida > 0);
  }

  /* ---------------------------------------------------------------------
     11. DESENHO
     --------------------------------------------------------------------- */
  function desenhar() {
    ctx.clearRect(0, 0, W, H);
    const camX = limitar(jogador.x - W / 2, 0, Math.max(0, MUNDO.w - W));
    const camY = limitar(jogador.y - H / 2, 0, Math.max(0, MUNDO.h - H));
    ctx.save();
    ctx.translate(-camX, -camY);

    // Piso
    ctx.fillStyle = "#07141b";
    ctx.fillRect(0, 0, MUNDO.w, MUNDO.h);
    for (let y = 0; y < MUNDO.h; y += 100)
      for (let x = 0; x < MUNDO.w; x += 130) {
        ctx.fillStyle = (x / 130 + y / 100) % 2 === 0 ? "#0c1f28" : "#0a1a22";
        ctx.fillRect(x + 2, y + 2, 126, 96);
        ctx.strokeStyle = "rgba(94,214,205,.12)";
        ctx.strokeRect(x + 2, y + 2, 126, 96);
      }

    desenharCenario();

    // Canal de água congelada no meio do mapa
    ctx.strokeStyle = "rgba(110,255,220,.16)";
    ctx.lineWidth = 60;
    ctx.beginPath();
    ctx.moveTo(90, MUNDO.h / 2);
    ctx.lineTo(MUNDO.w - 90, MUNDO.h / 2);
    ctx.stroke();

    // Muralha externa
    ctx.strokeStyle = "#2f5d62";
    ctx.lineWidth = 30;
    ctx.strokeRect(20, 20, MUNDO.w - 40, MUNDO.h - 40);

    // Símbolos espalhados
    ctx.font = "24px Georgia";
    ctx.fillStyle = "rgba(126,255,226,.22)";
    ctx.textAlign = "left";
    for (let i = 0; i < 50; i++) {
      const x = 120 + ((i * 197) % (MUNDO.w - 240));
      const y = 140 + ((i * 113) % (MUNDO.h - 280));
      ctx.fillText(["∛", "π", "∞", "x³", "Δ", "≠"][i % 6], x, y);
    }

    inimigos.forEach(desenharInimigo);
    desenharJogador();

    particulas.forEach((p) => {
      ctx.globalAlpha = Math.max(0, p.vida / p.max);
      ctx.fillStyle =
        p.tipo === "dano"
          ? "#ff5f7e"
          : p.tipo === "estouro"
            ? "#ffd166"
            : "#7dffe0";
      ctx.beginPath();
      ctx.arc(p.x, p.y, 3 + 8 * (p.vida / p.max), 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    });

    ctx.restore();
  }

  function desenharCenario() {
    const t = performance.now();
    cenario.forEach((d) => {
      ctx.save();
      ctx.translate(d.x, d.y);
      ctx.rotate(d.giro);
      ctx.scale(d.escala, d.escala);

      if (d.tipo === "obelisco") {
        ctx.fillStyle = "#16303a";
        ctx.beginPath();
        ctx.moveTo(-22, 80);
        ctx.lineTo(-14, -80);
        ctx.lineTo(14, -80);
        ctx.lineTo(22, 80);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = "#24525c";
        ctx.fillRect(-30, 74, 60, 14);
        ctx.fillStyle = "rgba(125,255,224,.35)";
        ctx.fillRect(-5, -66, 10, 130);
      } else if (d.tipo === "gelo") {
        ctx.fillStyle = "rgba(150,238,255,.75)";
        ctx.beginPath();
        ctx.moveTo(-18, -40);
        ctx.lineTo(18, -40);
        ctx.lineTo(4, 46);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = "rgba(255,255,255,.45)";
        ctx.beginPath();
        ctx.moveTo(-8, -34);
        ctx.lineTo(2, -34);
        ctx.lineTo(0, 16);
        ctx.closePath();
        ctx.fill();
      } else if (d.tipo === "engrenagem") {
        const giro = t / 2200;
        ctx.rotate(giro);
        ctx.fillStyle = "#3b3326";
        ctx.strokeStyle = "#c9953f";
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.arc(0, 0, 46, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        for (let i = 0; i < 10; i++) {
          const ang = (i / 10) * Math.PI * 2;
          ctx.save();
          ctx.rotate(ang);
          ctx.fillStyle = "#c9953f";
          ctx.fillRect(-7, -60, 14, 18);
          ctx.restore();
        }
        ctx.fillStyle = "#0b1a20";
        ctx.beginPath();
        ctx.arc(0, 0, 16, 0, Math.PI * 2);
        ctx.fill();
      } else if (d.tipo === "lago") {
        ctx.fillStyle = "rgba(76,190,200,.22)";
        ctx.beginPath();
        ctx.ellipse(0, 0, 90, 58, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "rgba(160,245,255,.35)";
        ctx.lineWidth = 3;
        ctx.stroke();
        ctx.strokeStyle = "rgba(200,255,255,.25)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(-60, -10);
        ctx.lineTo(-10, 12);
        ctx.lineTo(40, -18);
        ctx.stroke();
      } else if (d.tipo === "braseiro") {
        ctx.fillStyle = "#2a2a33";
        ctx.fillRect(-16, 10, 32, 26);
        ctx.fillStyle = "#3d3d49";
        ctx.fillRect(-24, 32, 48, 10);
        ctx.shadowBlur = 28;
        ctx.shadowColor = "#ffb545";
        ctx.fillStyle = "#ffc963";
        ctx.beginPath();
        ctx.arc(0, -2, 14 + Math.sin(t / 130) * 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      } else if (d.tipo === "arco") {
        ctx.strokeStyle = "#20444d";
        ctx.lineWidth = 16;
        ctx.beginPath();
        ctx.arc(0, 30, 60, Math.PI, Math.PI * 1.85);
        ctx.stroke();
        ctx.fillStyle = "#16333b";
        ctx.fillRect(-68, 20, 16, 70);
        ctx.fillRect(52, 34, 16, 56);
      } else if (d.tipo === "glifo") {
        ctx.strokeStyle = "rgba(126,255,226,.18)";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, 26, 0, Math.PI * 1.6);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(-18, 14);
        ctx.lineTo(16, -14);
        ctx.stroke();
      }
      ctx.restore();
    });
  }

  function desenharInimigo(e) {
    const flutua = Math.sin(e.fase) * 4;
    ctx.save();
    ctx.translate(e.x, e.y + flutua);

    if (e.chefe) {
      ctx.shadowBlur = 34;
      ctx.shadowColor = "#ffb545";
      ctx.fillStyle = "#23323c";
      ctx.beginPath();
      ctx.arc(0, 0, 56, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
      // anéis girando
      for (let i = 0; i < 3; i++) {
        ctx.strokeStyle = `rgba(255,209,102,${0.55 - i * 0.14})`;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.ellipse(
          0,
          0,
          70 + i * 12,
          26 + i * 6,
          e.fase * 0.5 + i,
          0,
          Math.PI * 2,
        );
        ctx.stroke();
      }
      ctx.fillStyle = "#ffd166";
      ctx.beginPath();
      ctx.arc(0, 0, 20, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#0c1a20";
      ctx.font = "bold 22px Georgia";
      ctx.textAlign = "center";
      ctx.fillText("Σ", 0, 8);
      ctx.fillStyle = "#10101a";
      ctx.fillRect(-60, -86, 120, 10);
      ctx.fillStyle = "#ffd166";
      ctx.fillRect(-60, -86, 120 * (e.hp / e.maxHp), 10);
    } else {
      ctx.shadowBlur = 20;
      ctx.shadowColor = e.ativo ? "#ff7ba5" : "#7dffe0";
      ctx.fillStyle = "#1d3d47";
      // corpo em losango (cristal)
      ctx.beginPath();
      ctx.moveTo(0, -36);
      ctx.lineTo(26, 0);
      ctx.lineTo(0, 36);
      ctx.lineTo(-26, 0);
      ctx.closePath();
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.fillStyle = e.ativo ? "#ff7ba5" : "#7dffe0";
      ctx.beginPath();
      ctx.arc(0, 0, 10, 0, Math.PI * 2);
      ctx.fill();
      // lascas orbitando
      for (let i = 0; i < 3; i++) {
        const ang = e.fase + (i * Math.PI * 2) / 3;
        ctx.fillStyle = "rgba(160,245,255,.8)";
        ctx.beginPath();
        ctx.arc(Math.cos(ang) * 40, Math.sin(ang) * 26, 5, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = "#10101a";
      ctx.fillRect(-32, -56, 64, 8);
      ctx.fillStyle = "#8ff4d8";
      ctx.fillRect(-32, -56, 64 * (e.hp / e.maxHp), 8);
    }
    ctx.restore();
  }

  // Mesmo mago da fase 1, com um manto dourado para marcar o avanço.
  function desenharJogador() {
    ctx.save();
    ctx.translate(jogador.x, jogador.y);
    ctx.shadowBlur = 20;
    ctx.shadowColor = "#ffd166";
    ctx.fillStyle = "#2f5d62";
    ctx.beginPath();
    ctx.moveTo(-22, 25);
    ctx.quadraticCurveTo(0, 42, 22, 25);
    ctx.lineTo(17, -8);
    ctx.lineTo(-17, -8);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#f0c6a7";
    ctx.beginPath();
    ctx.arc(0, -18, 14, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#123038";
    ctx.beginPath();
    ctx.moveTo(-24, -21);
    ctx.lineTo(0, -58);
    ctx.lineTo(24, -21);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#ffd166";
    ctx.fillRect(-25, -22, 50, 7);
    ctx.strokeStyle = "#d7b36c";
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(25, 28);
    ctx.lineTo(35, -30);
    ctx.stroke();
    ctx.fillStyle = "#7dffe0";
    ctx.beginPath();
    ctx.arc(36, -34, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.restore();
  }

  /* ---------------------------------------------------------------------
     12. LOOP
     Continua rodando mesmo depois do fim, para o cenário ficar congelado
     atrás da tela final em vez de sumir.
     --------------------------------------------------------------------- */
  function loop(t) {
    if (!ativo) {
      loopLigado = false;
      return;
    }
    const dt = Math.min(0.033, (t - anterior) / 1000);
    anterior = t;
    atualizar(dt);
    desenhar();
    requestAnimationFrame(loop);
  }

  /* ---------------------------------------------------------------------
     13. FIM DA FASE
     --------------------------------------------------------------------- */
  function encerrarFase(venceu) {
    if (terminada) return;
    terminada = true;
    fecharConta();
    mostrarElementosDaFase(false);

    const segundos = Math.max(0, (performance.now() - jogo.inicio) / 1000);
    const total = jogo.acertos + jogo.erros;
    const precisao = total ? Math.round((jogo.acertos / total) * 100) : 0;

    if (venceu) {
      ui.endTitle.textContent = "TORRE DOMINADA!";
      ui.grade.textContent =
        precisao >= 90
          ? "Arquimago Supremo!"
          : precisao >= 70
            ? "Excelente!"
            : "Missão cumprida!";
      ui.endMessage.textContent =
        "O Guardião foi desfeito e a fórmula mágica voltou às mãos de Pitágoras.";
    } else {
      ui.endTitle.textContent = "GAME OVER";
      ui.grade.textContent = "Você perdeu!";
      ui.endMessage.textContent =
        "As criptas venceram Pitágoras desta vez. A jornada recomeça na Torre de Heráclito.";
    }

    ui.stats.innerHTML =
      `Pontuação final: <b>${Number(jogo.pontos).toLocaleString("pt-BR")}</b><br>` +
      `Fase 2 — inimigos derrotados: <b>${jogo.abates}</b>/${ALVO_SENTINELAS}` +
      `${venceu ? " + Guardião" : ""}<br>` +
      `Precisão na fase 2: <b>${precisao}%</b><br>` +
      `Tempo na fase 2: <b>${formatarTempo(segundos)}</b>`;

    ui.end.classList.toggle("gameover", !venceu);
    ui.hud.style.display = "none";
    ui.bottom.style.display = "none";
    ui.end.style.display = "flex";
  }

  /* ---------------------------------------------------------------------
     14. API PÚBLICA (a ponte com o script.js)
     --------------------------------------------------------------------- */
  const api = {
    iniciar(estado) {
      estado = estado || {};
      ativo = true;
      tocarMusicaFase(2);
      terminada = false;
      inimigos = [];
      particulas = [];
      alvo = null;

      jogo = {
        hp: estado.hp || 7,
        maxHp: estado.maxHp || 7,
        vidas: estado.vidas || 3,
        pontos: estado.pontos || 0,
        erros: estado.erros || 0,
        acertos: 0,
        combo: 0,
        abates: 0,
        nivel: 2,
        spawn: 1.2,
        emConta: false,
        chefeVivo: false,
        tempo: TEMPO_RESPOSTA,
        tempoMax: TEMPO_RESPOSTA,
        inicio: performance.now(),
      };

      jogador = { x: 260, y: MUNDO.h / 2, r: 24 };

      // Prepara a interface
      ui.end.style.display = "none";
      ui.end.classList.remove("gameover");
      ui.hud.style.display = "block";
      ui.bottom.style.display = "block";
      ui.math.style.display = "none";
      ui.answer.value = "";
      if (ui.tutorial) {
        ui.tutorial.innerHTML =
          "<strong>FASE 2:</strong> as contas agora têm <b>tempo</b>. " +
          "Derrote <b>" +
          ALVO_SENTINELAS +
          " sentinelas</b> para acordar o Guardião de Arquimedes.";
      }
      selo.style.display = "block";
      tempoWrap.style.display = "none";

      ajustarTela();
      atualizarHud();
      aviso("FASE 2 — As Criptas de Arquimedes", 2600);
      clarao("#ffd166");

      if (!loopLigado) {
        loopLigado = true;
        anterior = performance.now();
        requestAnimationFrame(loop);
      }
    },

    ativa() {
      return ativo;
    },

    encerrar() {
      ativo = false;
      terminada = false;
      jogo = null;
      inimigos = [];
      particulas = [];
      alvo = null;
      mostrarElementosDaFase(false);
      if (ui.tutorial) {
        ui.tutorial.innerHTML =
          "<strong>CONTROLES:</strong> <kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd> " +
          "ou <kbd>↑</kbd><kbd>←</kbd><kbd>↓</kbd><kbd>→</kbd> para explorar. " +
          '<span class="tip">Quando um inimigo aparecer, resolva a conta e pressione Enter.</span>';
      }
    },
  };

  // "JOGAR NOVAMENTE" devolve o controle ao script.js (volta para a fase 1).
  // Este listener é registrado antes do onclick do script.js, então roda antes.
  const btnRestart = document.getElementById("restartBtn");
  if (btnRestart) btnRestart.addEventListener("click", () => api.encerrar());

  window.FASE2 = api;
})();